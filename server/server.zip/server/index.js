/**
 * DBZ RPG Server - Single Process Multi Server
 * Boot: 1 SQLite DB → start 4 servers (Login, Main, Chat, Dungeon)
 */
'use strict';

require('dotenv').config();

const Database = require('better-sqlite3');
const { createServer } = require('http');
const { Server: IOServer } = require('socket.io');
const express = require('express');

// =============================================
// 1. Open 1 shared SQLite DB
// =============================================
const dbPath = process.env.DB_PATH || './game.db';
const db = new Database(dbPath);

// Enable WAL mode for concurrent reads across 4 servers
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.pragma('synchronous = NORMAL');

console.log(`[BOOT] Database opened: ${dbPath}`);
console.log(`[BOOT] WAL mode enabled, busy_timeout=5000ms`);

// =============================================
// 2. TEA encryption utilities (inline, no extra files)
// =============================================
const TEA_DELTA = 0x9E3779B9;
const TEA_KEY = (process.env.TEA_KEY || 'verification').split('').map(c => c.charCodeAt(0));

function teaEncrypt(v, key) {
  const k = key || TEA_KEY;
  const rounds = 16;
  let v0 = v[0], v1 = v[1];
  let sum = 0;
  for (let i = 0; i < rounds; i++) {
    sum = (sum + TEA_DELTA) >>> 0;
    v0 = (v0 + (((v1 << 4) + k[0]) ^ (v1 + sum) ^ ((v1 >>> 5) + k[1]))) >>> 0;
    v1 = (v1 + (((v0 << 4) + k[2]) ^ (v0 + sum) ^ ((v0 >>> 5) + k[3]))) >>> 0;
  }
  return [v0, v1];
}

function stringToUint32Array(str) {
  const arr = [];
  for (let i = 0; i < str.length; i += 4) {
    const chunk = str.substring(i, i + 4);
    let val = 0;
    for (let j = 0; j < 4; j++) {
      if (j < chunk.length) val = (val << 8) | chunk.charCodeAt(j);
      else val = val << 8;
    }
    arr.push(val >>> 0);
  }
  return arr;
}

function teaEncryptString(str, key) {
  const arr = stringToUint32Array(str);
  if (arr.length === 0) return '';
  if (arr.length % 2 !== 0) arr.push(0);
  const result = [];
  for (let i = 0; i < arr.length; i += 2) {
    const enc = teaEncrypt([arr[i], arr[i + 1]], key);
    result.push(enc[0], enc[1]);
  }
  // Convert uint32 array to bytes then base64
  const bytes = Buffer.alloc(result.length * 4);
  for (let i = 0; i < result.length; i++) {
    bytes.writeUInt32BE(result[i], i * 4);
  }
  return bytes.toString('base64');
}

// =============================================
// 3. Response helper (inline)
// =============================================
function buildResponse(data, compress = false) {
  return {
    ret: 0,
    data: typeof data === 'string' ? data : JSON.stringify(data),
    compress: compress,
    serverTime: Date.now(),
    server0Time: Date.now()
  };
}

function buildErrorResponse(errorCode, errorMsg) {
  return {
    ret: -1,
    data: JSON.stringify({ errorCode, errorMsg }),
    compress: false,
    serverTime: Date.now(),
    server0Time: Date.now()
  };
}

// =============================================
// 4. Handler loader (dynamic require from folder)
// =============================================
function loadHandlers(handlersDir) {
  const fs = require('fs');
  const path = require('path');
  const absDir = path.join(__dirname, handlersDir);
  const handlers = {};
  if (!fs.existsSync(absDir)) return handlers;

  const items = fs.readdirSync(absDir, { withFileTypes: true });
  for (const item of items) {
    if (item.isDirectory()) {
      // Each subfolder = type name. Load all .js files inside as action handlers
      const typeDir = path.join(absDir, item.name);
      const typeHandlers = {};
      const actionFiles = fs.readdirSync(typeDir).filter(f => f.endsWith('.js'));
      for (const file of actionFiles) {
        const actionName = file.replace('.js', '');
        try {
          const mod = require(path.join(typeDir, file));
          typeHandlers[actionName] = typeof mod === 'function' ? mod : mod;
        } catch (err) {
          console.error(`[HANDLER] Failed to load ${item.name}/${file}: ${err.message}`);
        }
      }
      if (Object.keys(typeHandlers).length > 0) {
        handlers[item.name] = typeHandlers;
      }
    } else if (item.isFile() && item.name.endsWith('.js')) {
      // Single file in handlers root (login/chat style: exports = { action1, action2, ... })
      const typeName = item.name.replace('.js', '');
      try {
        const mod = require(path.join(absDir, item.name));
        handlers[typeName] = mod;
      } catch (err) {
        console.error(`[HANDLER] Failed to load ${item.name}: ${err.message}`);
      }
    }
  }
  return handlers;
}

// =============================================
// 5. Socket.IO engine setup helper
// =============================================
function createIOServer(port, opts = {}) {
  const httpServer = createServer();
  const io = new IOServer(httpServer, {
    cors: { origin: '*', methods: ['GET', 'POST'] },
    pingInterval: 10000,
    pingTimeout: 15000,
    maxHttpBufferSize: 1e7, // 10MB
    ...opts
  });
  return { httpServer, io, port };
}

// =============================================
// 6. TEA verify middleware
// =============================================
function setupTeaVerify(io) {
  io.on('connection', (socket) => {
    let verified = false;

    socket.on('verify', (challenge, callback) => {
      try {
        const encrypted = teaEncryptString(challenge);
        callback(encrypted);
        verified = true;
        console.log(`[TEA] Client ${socket.id} verified`);
      } catch (err) {
        console.error(`[TEA] Verify failed for ${socket.id}: ${err.message}`);
        callback && callback(null);
      }
    });

    // Store verified status on socket
    socket._verified = false;
    socket._setVerified = () => { socket._verified = true; };
  });
}

// =============================================
// 7. handler.process router middleware
// =============================================
function setupHandlerRouter(io, handlers) {
  io.on('connection', (socket) => {
    socket.on('handler.process', async (data, callback) => {
      const { type, action, ...params } = data;

      if (!type || !action) {
        return callback && callback(buildErrorResponse(1, 'Missing type or action'));
      }

      const typeHandlers = handlers[type];
      if (!typeHandlers) {
        console.warn(`[ROUTE] Unknown type: ${type}`);
        return callback && callback(buildErrorResponse(2, `Unknown handler type: ${type}`));
      }

      const handler = typeHandlers[action];
      if (!handler) {
        console.warn(`[ROUTE] Unknown action: ${type}.${action}`);
        return callback && callback(buildErrorResponse(3, `Unknown action: ${type}.${action}`));
      }

      try {
        if (typeof handler === 'function') {
          // Single exported function (main-server action files)
          await handler(params, socket, callback);
        } else if (typeof handler === 'object') {
          // Object with action methods (login/chat style)
          const method = handler[action];
          if (typeof method === 'function') {
            await method(params, socket, callback);
          } else {
            console.warn(`[ROUTE] Method not found: ${type}.${action}`);
            return callback && callback(buildErrorResponse(3, `Unknown action: ${type}.${action}`));
          }
        }
      } catch (err) {
        console.error(`[ROUTE] Error in ${type}.${action}: ${err.message}`);
        callback && callback(buildErrorResponse(999, err.message));
      }
    });
  });
}

// =============================================
// 8. Start Login Server (NO TEA)
// =============================================
function startLoginServer(db) {
  const { httpServer, io, port } = createIOServer(
    parseInt(process.env.LOGIN_PORT) || 8000
  );

  // Init DB schema
  const initDB = require('./login-server/db');
  initDB(db);

  // Load handlers
  const handlers = loadHandlers('./login-server/handlers');
  console.log(`[login-server] Loaded types: ${Object.keys(handlers).join(', ')}`);

  // Setup router (NO TEA verify for login)
  setupHandlerRouter(io, handlers);

  httpServer.listen(port, () => {
    console.log(`[login-server] Listening on port ${port} (NO TEA)`);
  });

  return { httpServer, io };
}

// =============================================
// 9. Start Main Server (TEA ON)
// =============================================
function startMainServer(db) {
  const { httpServer, io, port } = createIOServer(
    parseInt(process.env.MAIN_PORT) || 8001
  );

  // Init DB schema
  const initDB = require('./main-server/db');
  initDB(db);

  // Load handlers
  const handlers = loadHandlers('./main-server/handlers');
  console.log(`[main-server] Loaded ${Object.keys(handlers).length} types`);

  // Setup TEA verify
  setupTeaVerify(io);

  // Setup router
  setupHandlerRouter(io, handlers);

  httpServer.listen(port, () => {
    console.log(`[main-server] Listening on port ${port} (TEA ON)`);
  });

  return { httpServer, io };
}

// =============================================
// 10. Start Chat Server (TEA ON)
// =============================================
function startChatServer(db) {
  const { httpServer, io, port } = createIOServer(
    parseInt(process.env.CHAT_PORT) || 8581
  );

  // Init DB schema
  const initDB = require('./chat-server/db');
  initDB(db);

  // Load handlers
  const handlers = loadHandlers('./chat-server/handlers');
  console.log(`[chat-server] Loaded types: ${Object.keys(handlers).join(', ')}`);

  // Setup TEA verify
  setupTeaVerify(io);

  // Setup router
  setupHandlerRouter(io, handlers);

  httpServer.listen(port, () => {
    console.log(`[chat-server] Listening on port ${port} (TEA ON)`);
  });

  return { httpServer, io };
}

// =============================================
// 11. Start Dungeon Server (TEA ON + HTTP)
// =============================================
function startDungeonServer(db) {
  const wsPort = parseInt(process.env.DUNGEON_WS_PORT) || 8041;
  const httpPort = parseInt(process.env.DUNGEON_HTTP_PORT) || 8042;

  // Init DB schema
  const initDB = require('./dungeon-server/db');
  initDB(db);

  // --- WebSocket part ---
  const { httpServer: wsServer, io } = createIOServer(wsPort);

  // Load handlers (WS actions only)
  const handlers = loadHandlers('./dungeon-server/handlers');
  console.log(`[dungeon-server] Loaded types: ${Object.keys(handlers).join(', ')}`);

  // Setup TEA verify
  setupTeaVerify(io);

  // Setup WS router
  setupHandlerRouter(io, handlers);

  wsServer.listen(wsPort, () => {
    console.log(`[dungeon-server] WebSocket listening on port ${wsPort} (TEA ON)`);
  });

  // --- HTTP POST part ---
  const httpApp = express();
  httpApp.use(express.urlencoded({ extended: true, limit: '10mb' }));
  httpApp.use(express.json({ limit: '10mb' }));

  // HTTP dungeon handlers (queryTodayMap, queryRobot, etc.)
  const httpHandlers = handlers['teamDungeonTeam'] || {};

  httpApp.post('/', async (req, res) => {
    try {
      // Client sends: data=<JSON string>
      let body = req.body;
      if (body.data) {
        body = JSON.parse(body.data);
      }
      const { type, action, ...params } = body;

      if (!type || !action) {
        return res.json(buildErrorResponse(1, 'Missing type or action'));
      }

      const handler = httpHandlers[action];
      if (!handler || typeof handler !== 'function') {
        return res.json(buildErrorResponse(3, `Unknown action: ${type}.${action}`));
      }

      // HTTP handlers receive (params, req, res) instead of (params, socket, cb)
      await handler(params, req, res);
    } catch (err) {
      console.error(`[dungeon-http] Error: ${err.message}`);
      res.json(buildErrorResponse(999, err.message));
    }
  });

  httpApp.listen(httpPort, () => {
    console.log(`[dungeon-server] HTTP listening on port ${httpPort}`);
  });

  return { wsServer, io, httpApp };
}

// =============================================
// 12. BOOT SEQUENCE
// =============================================
console.log('========================================');
console.log('  DBZ RPG Natural Server - Starting');
console.log('========================================');

try {
  startLoginServer(db);
  startMainServer(db);
  startChatServer(db);
  startDungeonServer(db);

  console.log('========================================');
  console.log('  All 4 servers started successfully');
  console.log('========================================');

  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\n[SHUTDOWN] Closing database...');
    db.close();
    process.exit(0);
  });

  process.on('SIGTERM', () => {
    console.log('\n[SHUTDOWN] Closing database...');
    db.close();
    process.exit(0);
  });

} catch (err) {
  console.error('[BOOT] Fatal error:', err);
  db.close();
  process.exit(1);
}
