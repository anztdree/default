/**
 * enterGame Response Builder
 * Builds ~80 key data blob from DB for enterGame response
 * Auto-generated skeleton placeholder
 */
'use strict';
module.exports = function buildEnterGameData(db, userId) {
  // TODO: query all user data from DB and build enterGame response blob
  console.log('[main-server/enterGameBuilder] placeholder for user:', userId);
  return {};
};
