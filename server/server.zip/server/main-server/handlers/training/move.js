/**
 * [training] move
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement move
  console.log('[training] move called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
