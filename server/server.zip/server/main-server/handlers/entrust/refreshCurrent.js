/**
 * [entrust] refreshCurrent
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement refreshCurrent
  console.log('[entrust] refreshCurrent called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
