/**
 * [imprint] autoTakeOff
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement autoTakeOff
  console.log('[imprint] autoTakeOff called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
