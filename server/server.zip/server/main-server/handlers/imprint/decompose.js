/**
 * [imprint] decompose
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement decompose
  console.log('[imprint] decompose called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
