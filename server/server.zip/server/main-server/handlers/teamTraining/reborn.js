/**
 * [teamTraining] reborn
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement reborn
  console.log('[teamTraining] reborn called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
