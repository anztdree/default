/**
 * [guild] updateRequestCondition
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement updateRequestCondition
  console.log('[guild] updateRequestCondition called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
