/**
 * [guild] getGuildList
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement getGuildList
  console.log('[guild] getGuildList called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
