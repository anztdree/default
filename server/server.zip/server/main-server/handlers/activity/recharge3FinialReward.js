/**
 * [activity] recharge3FinialReward
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement recharge3FinialReward
  console.log('[activity] recharge3FinialReward called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
