/**
 * [activity] handleRefreshImprintResult
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement handleRefreshImprintResult
  console.log('[activity] handleRefreshImprintResult called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
