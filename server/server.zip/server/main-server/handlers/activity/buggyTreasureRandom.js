/**
 * [activity] buggyTreasureRandom
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement buggyTreasureRandom
  console.log('[activity] buggyTreasureRandom called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
