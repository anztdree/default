/**
 * [user] readBulletin
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement readBulletin
  console.log('[user] readBulletin called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
