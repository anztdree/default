/**
 * [resonance] putChild
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement putChild
  console.log('[resonance] putChild called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
