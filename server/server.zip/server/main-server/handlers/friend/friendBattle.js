/**
 * [friend] friendBattle
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement friendBattle
  console.log('[friend] friendBattle called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
