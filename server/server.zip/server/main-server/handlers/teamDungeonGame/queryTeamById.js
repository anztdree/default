/**
 * [teamDungeonGame] queryTeamById
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement queryTeamById
  console.log('[teamDungeonGame] queryTeamById called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
