/**
 * [war] getSignUpInfo
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement getSignUpInfo
  console.log('[war] getSignUpInfo called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
