/**
 * [hero] heroBreak
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement heroBreak
  console.log('[hero] heroBreak called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
