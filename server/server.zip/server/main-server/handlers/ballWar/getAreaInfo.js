/**
 * [ballWar] getAreaInfo
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement getAreaInfo
  console.log('[ballWar] getAreaInfo called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
