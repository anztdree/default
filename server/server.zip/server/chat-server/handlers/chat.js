/**
 * [chat] Chat Server Handler
 * Actions: login, joinRoom, leaveRoom, sendMsg, getRecord
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../db');

module.exports = {
  login: async function(params, socket, cb) {
    console.log('[chat] login called', params.userId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  },
  joinRoom: async function(params, socket, cb) {
    console.log('[chat] joinRoom called', params.userId, params.roomId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  },
  leaveRoom: async function(params, socket, cb) {
    console.log('[chat] leaveRoom called', params.userId, params.roomId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  },
  sendMsg: async function(params, socket, cb) {
    console.log('[chat] sendMsg called', params.userId, params.roomId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  },
  getRecord: async function(params, socket, cb) {
    console.log('[chat] getRecord called', params.userId, params.roomId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0, records: [] }) });
  }
};
