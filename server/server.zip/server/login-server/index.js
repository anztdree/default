/**
 * Login Server - Socket.IO (NO TEA)
 * Port: 8000
 * Auto-generated skeleton placeholder
 */
'use strict';
module.exports = function startLoginServer(db, io) {
  // TODO: implement login server
  console.log('[login-server] placeholder');
};
