/**
 * [User] Login Server Handler
 * Actions: loginGame, GetServerList, LoginAnnounce, SaveHistory, SaveUserEnterInfo, SaveLanguage
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../db');

module.exports = {
  loginGame: async function(params, socket, cb) {
    console.log('[User] loginGame called', params.userId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  },
  GetServerList: async function(params, socket, cb) {
    console.log('[User] GetServerList called', params.userId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0, serverList: [] }) });
  },
  LoginAnnounce: async function(params, socket, cb) {
    console.log('[User] LoginAnnounce called');
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0, announcements: [] }) });
  },
  SaveHistory: async function(params, socket, cb) {
    console.log('[User] SaveHistory called', params.serverId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0, loginToken: '' }) });
  },
  SaveUserEnterInfo: async function(params, socket, cb) {
    console.log('[User] SaveUserEnterInfo called', params.userId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  },
  SaveLanguage: async function(params, socket, cb) {
    console.log('[User] SaveLanguage called', params.userId);
    cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
  }
};
