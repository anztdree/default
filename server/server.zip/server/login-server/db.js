/**
 * Login Server Database Schema
 * Tables: users, login_tokens, server_list
 * Auto-generated skeleton placeholder
 */
'use strict';
module.exports = function initLoginDB(db) {
  // TODO: create login tables
  console.log('[login-server/db] placeholder');
};
