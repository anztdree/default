/**
 * [teamDungeonTeam] startBattle (WS)
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement startBattle (WS)
  console.log('[teamDungeonTeam] startBattle (WS) called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
