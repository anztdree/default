/**
 * [teamDungeonTeam] changeAutoJoinCondition (WS)
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement changeAutoJoinCondition (WS)
  console.log('[teamDungeonTeam] changeAutoJoinCondition (WS) called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
