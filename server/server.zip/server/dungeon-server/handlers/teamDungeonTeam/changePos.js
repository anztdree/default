/**
 * [teamDungeonTeam] changePos (WS)
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement changePos (WS)
  console.log('[teamDungeonTeam] changePos (WS) called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
