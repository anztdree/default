/**
 * [teamDungeonTeam] queryHistoryMap (HTTP POST)
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, req, res) {
  // TODO: implement queryHistoryMap
  console.log('[teamDungeonTeam] queryHistoryMap called (HTTP)');
  res.json({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
