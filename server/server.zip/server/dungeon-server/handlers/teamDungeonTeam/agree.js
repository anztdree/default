/**
 * [teamDungeonTeam] agree (WS)
 * Auto-generated skeleton placeholder
 */
'use strict';

const db = require('../../db');

module.exports = async function(params, socket, cb) {
  // TODO: implement agree (WS)
  console.log('[teamDungeonTeam] agree (WS) called', params.userId);
  cb({ ret: 0, data: JSON.stringify({ errorCode: 0 }) });
};
