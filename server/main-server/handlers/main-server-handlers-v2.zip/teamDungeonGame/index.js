/**
 * ============================================================================
 * TeamDungeonGame Handler — Main Server (Router)
 * ============================================================================
 * Actions: addRobot, agree, apply, autoApply, changeAutoJoinCondition, clientConnect, createTeam, friendServerAction, getAchReward, getAllReward, getDailyTaskReward, getFriendArenaDefenceTeam, getReward, queryBattleRecord, queryKillRank, queryMyApplyList, queryMyRecord, queryRobot, queryTeam, queryTeamByDisplayId, queryTeamById, queryTeamMembers, queryTeamsMember, queryUserTeam, quitTeam, recommendBattleFriend, refreshApplyList, setTeamDungeonTeam, startBattle, updateTreasureDefenceTeam
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var addRobot = require('./addRobot');
var agree = require('./agree');
var apply = require('./apply');
var autoApply = require('./autoApply');
var changeAutoJoinCondition = require('./changeAutoJoinCondition');
var clientConnect = require('./clientConnect');
var createTeam = require('./createTeam');
var friendServerAction = require('./friendServerAction');
var getAchReward = require('./getAchReward');
var getAllReward = require('./getAllReward');
var getDailyTaskReward = require('./getDailyTaskReward');
var getFriendArenaDefenceTeam = require('./getFriendArenaDefenceTeam');
var getReward = require('./getReward');
var queryBattleRecord = require('./queryBattleRecord');
var queryKillRank = require('./queryKillRank');
var queryMyApplyList = require('./queryMyApplyList');
var queryMyRecord = require('./queryMyRecord');
var queryRobot = require('./queryRobot');
var queryTeam = require('./queryTeam');
var queryTeamByDisplayId = require('./queryTeamByDisplayId');
var queryTeamById = require('./queryTeamById');
var queryTeamMembers = require('./queryTeamMembers');
var queryTeamsMember = require('./queryTeamsMember');
var queryUserTeam = require('./queryUserTeam');
var quitTeam = require('./quitTeam');
var recommendBattleFriend = require('./recommendBattleFriend');
var refreshApplyList = require('./refreshApplyList');
var setTeamDungeonTeam = require('./setTeamDungeonTeam');
var startBattle = require('./startBattle');
var updateTreasureDefenceTeam = require('./updateTreasureDefenceTeam');

var actions = {
  addRobot: addRobot,
  agree: agree,
  apply: apply,
  autoApply: autoApply,
  changeAutoJoinCondition: changeAutoJoinCondition,
  clientConnect: clientConnect,
  createTeam: createTeam,
  friendServerAction: friendServerAction,
  getAchReward: getAchReward,
  getAllReward: getAllReward,
  getDailyTaskReward: getDailyTaskReward,
  getFriendArenaDefenceTeam: getFriendArenaDefenceTeam,
  getReward: getReward,
  queryBattleRecord: queryBattleRecord,
  queryKillRank: queryKillRank,
  queryMyApplyList: queryMyApplyList,
  queryMyRecord: queryMyRecord,
  queryRobot: queryRobot,
  queryTeam: queryTeam,
  queryTeamByDisplayId: queryTeamByDisplayId,
  queryTeamById: queryTeamById,
  queryTeamMembers: queryTeamMembers,
  queryTeamsMember: queryTeamsMember,
  queryUserTeam: queryUserTeam,
  quitTeam: quitTeam,
  recommendBattleFriend: recommendBattleFriend,
  refreshApplyList: refreshApplyList,
  setTeamDungeonTeam: setTeamDungeonTeam,
  startBattle: startBattle,
  updateTreasureDefenceTeam: updateTreasureDefenceTeam,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('TeamDungeonGame', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
