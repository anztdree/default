/**
 * ============================================================================
 * Expedition Handler — Main Server (Router)
 * ============================================================================
 * Actions: checkBattleResult, clickExpedition, collection, delTeam, finishEvent, getLog, investigation, levelUpMachine, putInMachine, quickFinishEvent, saveTeam, setTeam, signUpBallWar, startBattle, startEvent, takeOutMachine, unlockMachine
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var checkBattleResult = require('./checkBattleResult');
var clickExpedition = require('./clickExpedition');
var collection = require('./collection');
var delTeam = require('./delTeam');
var finishEvent = require('./finishEvent');
var getLog = require('./getLog');
var investigation = require('./investigation');
var levelUpMachine = require('./levelUpMachine');
var putInMachine = require('./putInMachine');
var quickFinishEvent = require('./quickFinishEvent');
var saveTeam = require('./saveTeam');
var setTeam = require('./setTeam');
var signUpBallWar = require('./signUpBallWar');
var startBattle = require('./startBattle');
var startEvent = require('./startEvent');
var takeOutMachine = require('./takeOutMachine');
var unlockMachine = require('./unlockMachine');

var actions = {
  checkBattleResult: checkBattleResult,
  clickExpedition: clickExpedition,
  collection: collection,
  delTeam: delTeam,
  finishEvent: finishEvent,
  getLog: getLog,
  investigation: investigation,
  levelUpMachine: levelUpMachine,
  putInMachine: putInMachine,
  quickFinishEvent: quickFinishEvent,
  saveTeam: saveTeam,
  setTeam: setTeam,
  signUpBallWar: signUpBallWar,
  startBattle: startBattle,
  startEvent: startEvent,
  takeOutMachine: takeOutMachine,
  unlockMachine: unlockMachine,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Expedition', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
