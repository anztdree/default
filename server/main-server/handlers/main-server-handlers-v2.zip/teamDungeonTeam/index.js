/**
 * ============================================================================
 * TeamDungeonTeam Handler — Main Server (Router)
 * ============================================================================
 * Actions: agree, apply, changeAutoJoinCondition, changePos, clientConnect, friendServerAction, getAchReward, getFriendArenaDefenceTeam, queryBattleRecord, queryHistoryMap, queryMyApplyList, queryRobot, queryTeamByDisplayId, queryTeamMembers, queryTeamRecord, queryTodayMap, queryUserTeam, refreshApplyList, startBattle
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var agree = require('./agree');
var apply = require('./apply');
var changeAutoJoinCondition = require('./changeAutoJoinCondition');
var changePos = require('./changePos');
var clientConnect = require('./clientConnect');
var friendServerAction = require('./friendServerAction');
var getAchReward = require('./getAchReward');
var getFriendArenaDefenceTeam = require('./getFriendArenaDefenceTeam');
var queryBattleRecord = require('./queryBattleRecord');
var queryHistoryMap = require('./queryHistoryMap');
var queryMyApplyList = require('./queryMyApplyList');
var queryRobot = require('./queryRobot');
var queryTeamByDisplayId = require('./queryTeamByDisplayId');
var queryTeamMembers = require('./queryTeamMembers');
var queryTeamRecord = require('./queryTeamRecord');
var queryTodayMap = require('./queryTodayMap');
var queryUserTeam = require('./queryUserTeam');
var refreshApplyList = require('./refreshApplyList');
var startBattle = require('./startBattle');

var actions = {
  agree: agree,
  apply: apply,
  changeAutoJoinCondition: changeAutoJoinCondition,
  changePos: changePos,
  clientConnect: clientConnect,
  friendServerAction: friendServerAction,
  getAchReward: getAchReward,
  getFriendArenaDefenceTeam: getFriendArenaDefenceTeam,
  queryBattleRecord: queryBattleRecord,
  queryHistoryMap: queryHistoryMap,
  queryMyApplyList: queryMyApplyList,
  queryRobot: queryRobot,
  queryTeamByDisplayId: queryTeamByDisplayId,
  queryTeamMembers: queryTeamMembers,
  queryTeamRecord: queryTeamRecord,
  queryTodayMap: queryTodayMap,
  queryUserTeam: queryUserTeam,
  refreshApplyList: refreshApplyList,
  startBattle: startBattle,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('TeamDungeonTeam', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
