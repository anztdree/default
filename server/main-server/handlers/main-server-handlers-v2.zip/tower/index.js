/**
 * ============================================================================
 * Tower Handler — Main Server (Router)
 * ============================================================================
 * Actions: autoGetEventsReward, buyBattleTimes, buyClimbTimes, climb, getAllRank, getFeetInfo, getLocalRank, getReward, openBox, openKarin, openTimesEvent, queryPlayerHeadIcon, startBattle, topAward
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var autoGetEventsReward = require('./autoGetEventsReward');
var buyBattleTimes = require('./buyBattleTimes');
var buyClimbTimes = require('./buyClimbTimes');
var climb = require('./climb');
var getAllRank = require('./getAllRank');
var getFeetInfo = require('./getFeetInfo');
var getLocalRank = require('./getLocalRank');
var getReward = require('./getReward');
var openBox = require('./openBox');
var openKarin = require('./openKarin');
var openTimesEvent = require('./openTimesEvent');
var queryPlayerHeadIcon = require('./queryPlayerHeadIcon');
var startBattle = require('./startBattle');
var topAward = require('./topAward');

var actions = {
  autoGetEventsReward: autoGetEventsReward,
  buyBattleTimes: buyBattleTimes,
  buyClimbTimes: buyClimbTimes,
  climb: climb,
  getAllRank: getAllRank,
  getFeetInfo: getFeetInfo,
  getLocalRank: getLocalRank,
  getReward: getReward,
  openBox: openBox,
  openKarin: openKarin,
  openTimesEvent: openTimesEvent,
  queryPlayerHeadIcon: queryPlayerHeadIcon,
  startBattle: startBattle,
  topAward: topAward,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Tower', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
