/**
 * ============================================================================
 * TopBattle Handler — Main Server (Router)
 * ============================================================================
 * Actions: bet, buyTimes, getBattleRecord, getBetReward, getGuildByIdOrName, getRank, getRankReward, getTeamInfo, getTopBattleRecord, like, queryArenaHeroEquipInfo, queryBackupTeam, queryBackupTeamEquip, queryHistory, queryHistoryList, queryRank, queryUserHistory, reborn, select, setTeam, startBattle, startSeason, tryMatch
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var bet = require('./bet');
var buyTimes = require('./buyTimes');
var getBattleRecord = require('./getBattleRecord');
var getBetReward = require('./getBetReward');
var getGuildByIdOrName = require('./getGuildByIdOrName');
var getRank = require('./getRank');
var getRankReward = require('./getRankReward');
var getTeamInfo = require('./getTeamInfo');
var getTopBattleRecord = require('./getTopBattleRecord');
var like = require('./like');
var queryArenaHeroEquipInfo = require('./queryArenaHeroEquipInfo');
var queryBackupTeam = require('./queryBackupTeam');
var queryBackupTeamEquip = require('./queryBackupTeamEquip');
var queryHistory = require('./queryHistory');
var queryHistoryList = require('./queryHistoryList');
var queryRank = require('./queryRank');
var queryUserHistory = require('./queryUserHistory');
var reborn = require('./reborn');
var select = require('./select');
var setTeam = require('./setTeam');
var startBattle = require('./startBattle');
var startSeason = require('./startSeason');
var tryMatch = require('./tryMatch');

var actions = {
  bet: bet,
  buyTimes: buyTimes,
  getBattleRecord: getBattleRecord,
  getBetReward: getBetReward,
  getGuildByIdOrName: getGuildByIdOrName,
  getRank: getRank,
  getRankReward: getRankReward,
  getTeamInfo: getTeamInfo,
  getTopBattleRecord: getTopBattleRecord,
  like: like,
  queryArenaHeroEquipInfo: queryArenaHeroEquipInfo,
  queryBackupTeam: queryBackupTeam,
  queryBackupTeamEquip: queryBackupTeamEquip,
  queryHistory: queryHistory,
  queryHistoryList: queryHistoryList,
  queryRank: queryRank,
  queryUserHistory: queryUserHistory,
  reborn: reborn,
  select: select,
  setTeam: setTeam,
  startBattle: startBattle,
  startSeason: startSeason,
  tryMatch: tryMatch,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('TopBattle', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
