/**
 * ============================================================================
 * Imprint Handler — Main Server (Router)
 * ============================================================================
 * Actions: activeSkin, addAttr, autoTakeOff, autoWear, buy, decompose, getActivityBrief, getMsgList, handleRefreshImprintResult, levelUp, merge, queryImprint, reborn, rebornSelfBreak, splitHero, starUp, takeOff, wear
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var activeSkin = require('./activeSkin');
var addAttr = require('./addAttr');
var autoTakeOff = require('./autoTakeOff');
var autoWear = require('./autoWear');
var buy = require('./buy');
var decompose = require('./decompose');
var getActivityBrief = require('./getActivityBrief');
var getMsgList = require('./getMsgList');
var handleRefreshImprintResult = require('./handleRefreshImprintResult');
var levelUp = require('./levelUp');
var merge = require('./merge');
var queryImprint = require('./queryImprint');
var reborn = require('./reborn');
var rebornSelfBreak = require('./rebornSelfBreak');
var splitHero = require('./splitHero');
var starUp = require('./starUp');
var takeOff = require('./takeOff');
var wear = require('./wear');

var actions = {
  activeSkin: activeSkin,
  addAttr: addAttr,
  autoTakeOff: autoTakeOff,
  autoWear: autoWear,
  buy: buy,
  decompose: decompose,
  getActivityBrief: getActivityBrief,
  getMsgList: getMsgList,
  handleRefreshImprintResult: handleRefreshImprintResult,
  levelUp: levelUp,
  merge: merge,
  queryImprint: queryImprint,
  reborn: reborn,
  rebornSelfBreak: rebornSelfBreak,
  splitHero: splitHero,
  starUp: starUp,
  takeOff: takeOff,
  wear: wear,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Imprint', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
