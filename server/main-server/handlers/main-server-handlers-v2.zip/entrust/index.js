/**
 * ============================================================================
 * Entrust Handler — Main Server (Router)
 * ============================================================================
 * Actions: autoRingLevelUp, finishNow, getFriendHeros, getHelpReward, getHelpRewardInfo, getInfo, getReward, getTreasureInfo, refreshCurrent, reset, setHelpFriendHero, startEntrust, userEntrustBook
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var autoRingLevelUp = require('./autoRingLevelUp');
var finishNow = require('./finishNow');
var getFriendHeros = require('./getFriendHeros');
var getHelpReward = require('./getHelpReward');
var getHelpRewardInfo = require('./getHelpRewardInfo');
var getInfo = require('./getInfo');
var getReward = require('./getReward');
var getTreasureInfo = require('./getTreasureInfo');
var refreshCurrent = require('./refreshCurrent');
var reset = require('./reset');
var setHelpFriendHero = require('./setHelpFriendHero');
var startEntrust = require('./startEntrust');
var userEntrustBook = require('./userEntrustBook');

var actions = {
  autoRingLevelUp: autoRingLevelUp,
  finishNow: finishNow,
  getFriendHeros: getFriendHeros,
  getHelpReward: getHelpReward,
  getHelpRewardInfo: getHelpRewardInfo,
  getInfo: getInfo,
  getReward: getReward,
  getTreasureInfo: getTreasureInfo,
  refreshCurrent: refreshCurrent,
  reset: reset,
  setHelpFriendHero: setHelpFriendHero,
  startEntrust: startEntrust,
  userEntrustBook: userEntrustBook,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Entrust', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
