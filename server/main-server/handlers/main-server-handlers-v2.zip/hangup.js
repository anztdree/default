/**
 * ============================================================================
 * Hangup Handler — Main Server
 * ============================================================================
 * Actions: buyLessonFund, checkBattleResult, clickSystem, gain, getChapterReward, getFundReward, getLessonFundReward, getOnlineGift, nextChapter, saveGuideTeam, startGeneral, summonEnergy
 */

var ResponseHelper = require('../core/responseHelper');
var logger = require('../utils/logger');

var actions = {
  buyLessonFund: null,
  checkBattleResult: null,
  clickSystem: null,
  gain: null,
  getChapterReward: null,
  getFundReward: null,
  getLessonFundReward: null,
  getOnlineGift: null,
  nextChapter: null,
  saveGuideTeam: null,
  startGeneral: null,
  summonEnergy: null,
};

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler) {
    handler(socket, request, callback);
  } else {
    logger.warn('Hangup', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
