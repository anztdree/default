/**
 * ============================================================================
 * Friend Handler — Main Server (Router)
 * ============================================================================
 * Actions: addToBlacklist, applyFriend, autoGiveGetHeart, delFriend, findUserBrief, friendBattle, friendServerAction, getAllReward, getApplyList, getDailyTaskReward, getDetail, getFriendArenaDefenceTeam, getFriends, getHeart, getMsg, getReward, giveHeart, handleApply, handleRequest, move, putInMachine, queryBackupTeamEquip, queryKillRank, queryTeamRecord, queryUserTeam, quitTeam, readMsg, recommendBattleFriend, recommendFriend, removeBalcklist, sendMsg, setTeamDungeonTeam, startBoss, submitQuestionnaire, updateGuildIcon, wear
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var addToBlacklist = require('./addToBlacklist');
var applyFriend = require('./applyFriend');
var autoGiveGetHeart = require('./autoGiveGetHeart');
var delFriend = require('./delFriend');
var findUserBrief = require('./findUserBrief');
var friendBattle = require('./friendBattle');
var friendServerAction = require('./friendServerAction');
var getAllReward = require('./getAllReward');
var getApplyList = require('./getApplyList');
var getDailyTaskReward = require('./getDailyTaskReward');
var getDetail = require('./getDetail');
var getFriendArenaDefenceTeam = require('./getFriendArenaDefenceTeam');
var getFriends = require('./getFriends');
var getHeart = require('./getHeart');
var getMsg = require('./getMsg');
var getReward = require('./getReward');
var giveHeart = require('./giveHeart');
var handleApply = require('./handleApply');
var handleRequest = require('./handleRequest');
var move = require('./move');
var putInMachine = require('./putInMachine');
var queryBackupTeamEquip = require('./queryBackupTeamEquip');
var queryKillRank = require('./queryKillRank');
var queryTeamRecord = require('./queryTeamRecord');
var queryUserTeam = require('./queryUserTeam');
var quitTeam = require('./quitTeam');
var readMsg = require('./readMsg');
var recommendBattleFriend = require('./recommendBattleFriend');
var recommendFriend = require('./recommendFriend');
var removeBalcklist = require('./removeBalcklist');
var sendMsg = require('./sendMsg');
var setTeamDungeonTeam = require('./setTeamDungeonTeam');
var startBoss = require('./startBoss');
var submitQuestionnaire = require('./submitQuestionnaire');
var updateGuildIcon = require('./updateGuildIcon');
var wear = require('./wear');

var actions = {
  addToBlacklist: addToBlacklist,
  applyFriend: applyFriend,
  autoGiveGetHeart: autoGiveGetHeart,
  delFriend: delFriend,
  findUserBrief: findUserBrief,
  friendBattle: friendBattle,
  friendServerAction: friendServerAction,
  getAllReward: getAllReward,
  getApplyList: getApplyList,
  getDailyTaskReward: getDailyTaskReward,
  getDetail: getDetail,
  getFriendArenaDefenceTeam: getFriendArenaDefenceTeam,
  getFriends: getFriends,
  getHeart: getHeart,
  getMsg: getMsg,
  getReward: getReward,
  giveHeart: giveHeart,
  handleApply: handleApply,
  handleRequest: handleRequest,
  move: move,
  putInMachine: putInMachine,
  queryBackupTeamEquip: queryBackupTeamEquip,
  queryKillRank: queryKillRank,
  queryTeamRecord: queryTeamRecord,
  queryUserTeam: queryUserTeam,
  quitTeam: quitTeam,
  readMsg: readMsg,
  recommendBattleFriend: recommendBattleFriend,
  recommendFriend: recommendFriend,
  removeBalcklist: removeBalcklist,
  sendMsg: sendMsg,
  setTeamDungeonTeam: setTeamDungeonTeam,
  startBoss: startBoss,
  submitQuestionnaire: submitQuestionnaire,
  updateGuildIcon: updateGuildIcon,
  wear: wear,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Friend', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
