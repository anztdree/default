/**
 * ============================================================================
 * Gift Handler — Main Server (Router)
 * ============================================================================
 * Actions: GARoll, bsAddToHomeReward, buyFund, buyGold, buySuper, buyTimes, buyVipGift, checkin, click, clickHonghuUrl, getActivityDetail, getAllTaskReward, getChannelWeeklyRewrd, getFrisetRechargeReward, getInfo, getLevelReward, getOnlineGift, getRewardInfo, getVipReward, taskReward, useActiveCode
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var GARoll = require('./GARoll');
var bsAddToHomeReward = require('./bsAddToHomeReward');
var buyFund = require('./buyFund');
var buyGold = require('./buyGold');
var buySuper = require('./buySuper');
var buyTimes = require('./buyTimes');
var buyVipGift = require('./buyVipGift');
var checkin = require('./checkin');
var click = require('./click');
var clickHonghuUrl = require('./clickHonghuUrl');
var getActivityDetail = require('./getActivityDetail');
var getAllTaskReward = require('./getAllTaskReward');
var getChannelWeeklyRewrd = require('./getChannelWeeklyRewrd');
var getFrisetRechargeReward = require('./getFrisetRechargeReward');
var getInfo = require('./getInfo');
var getLevelReward = require('./getLevelReward');
var getOnlineGift = require('./getOnlineGift');
var getRewardInfo = require('./getRewardInfo');
var getVipReward = require('./getVipReward');
var taskReward = require('./taskReward');
var useActiveCode = require('./useActiveCode');

var actions = {
  GARoll: GARoll,
  bsAddToHomeReward: bsAddToHomeReward,
  buyFund: buyFund,
  buyGold: buyGold,
  buySuper: buySuper,
  buyTimes: buyTimes,
  buyVipGift: buyVipGift,
  checkin: checkin,
  click: click,
  clickHonghuUrl: clickHonghuUrl,
  getActivityDetail: getActivityDetail,
  getAllTaskReward: getAllTaskReward,
  getChannelWeeklyRewrd: getChannelWeeklyRewrd,
  getFrisetRechargeReward: getFrisetRechargeReward,
  getInfo: getInfo,
  getLevelReward: getLevelReward,
  getOnlineGift: getOnlineGift,
  getRewardInfo: getRewardInfo,
  getVipReward: getVipReward,
  taskReward: taskReward,
  useActiveCode: useActiveCode,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Gift', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
