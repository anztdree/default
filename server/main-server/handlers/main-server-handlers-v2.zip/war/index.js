/**
 * ============================================================================
 * War Handler — Main Server (Router)
 * ============================================================================
 * Actions: bet, checkBattleResult, getAuditionInfo, getAuditionRank, getAuditionReward, getBattleRecord, getBetReward, getChampionRank, getInfo, getSignUpInfo, getTeamInfo, getUserTeam, like, signUp, smelt, startBattle
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var bet = require('./bet');
var checkBattleResult = require('./checkBattleResult');
var getAuditionInfo = require('./getAuditionInfo');
var getAuditionRank = require('./getAuditionRank');
var getAuditionReward = require('./getAuditionReward');
var getBattleRecord = require('./getBattleRecord');
var getBetReward = require('./getBetReward');
var getChampionRank = require('./getChampionRank');
var getInfo = require('./getInfo');
var getSignUpInfo = require('./getSignUpInfo');
var getTeamInfo = require('./getTeamInfo');
var getUserTeam = require('./getUserTeam');
var like = require('./like');
var signUp = require('./signUp');
var smelt = require('./smelt');
var startBattle = require('./startBattle');

var actions = {
  bet: bet,
  checkBattleResult: checkBattleResult,
  getAuditionInfo: getAuditionInfo,
  getAuditionRank: getAuditionRank,
  getAuditionReward: getAuditionReward,
  getBattleRecord: getBattleRecord,
  getBetReward: getBetReward,
  getChampionRank: getChampionRank,
  getInfo: getInfo,
  getSignUpInfo: getSignUpInfo,
  getTeamInfo: getTeamInfo,
  getUserTeam: getUserTeam,
  like: like,
  signUp: signUp,
  smelt: smelt,
  startBattle: startBattle,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('War', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
