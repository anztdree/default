/**
 * ============================================================================
 * BallWar Handler — Main Server (Router)
 * ============================================================================
 * Actions: attackOwner, buyBossTimes, buyTimes, checkHaveDefence, getAreaInfo, getBriefInfo, getDetail, getFinishInfo, getFlagOwnerInfo, getFriendArenaDefenceTeam, getGuildMemberHonours, getPointRank, getRecord, removeDefence, setDefence, setTopMsg, signUpBallWar, startBattle
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var attackOwner = require('./attackOwner');
var buyBossTimes = require('./buyBossTimes');
var buyTimes = require('./buyTimes');
var checkHaveDefence = require('./checkHaveDefence');
var getAreaInfo = require('./getAreaInfo');
var getBriefInfo = require('./getBriefInfo');
var getDetail = require('./getDetail');
var getFinishInfo = require('./getFinishInfo');
var getFlagOwnerInfo = require('./getFlagOwnerInfo');
var getFriendArenaDefenceTeam = require('./getFriendArenaDefenceTeam');
var getGuildMemberHonours = require('./getGuildMemberHonours');
var getPointRank = require('./getPointRank');
var getRecord = require('./getRecord');
var removeDefence = require('./removeDefence');
var setDefence = require('./setDefence');
var setTopMsg = require('./setTopMsg');
var signUpBallWar = require('./signUpBallWar');
var startBattle = require('./startBattle');

var actions = {
  attackOwner: attackOwner,
  buyBossTimes: buyBossTimes,
  buyTimes: buyTimes,
  checkHaveDefence: checkHaveDefence,
  getAreaInfo: getAreaInfo,
  getBriefInfo: getBriefInfo,
  getDetail: getDetail,
  getFinishInfo: getFinishInfo,
  getFlagOwnerInfo: getFlagOwnerInfo,
  getFriendArenaDefenceTeam: getFriendArenaDefenceTeam,
  getGuildMemberHonours: getGuildMemberHonours,
  getPointRank: getPointRank,
  getRecord: getRecord,
  removeDefence: removeDefence,
  setDefence: setDefence,
  setTopMsg: setTopMsg,
  signUpBallWar: signUpBallWar,
  startBattle: startBattle,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('BallWar', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
