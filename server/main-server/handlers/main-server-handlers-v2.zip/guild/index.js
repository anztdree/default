/**
 * ============================================================================
 * Guild Handler — Main Server (Router)
 * ============================================================================
 * Actions: activeSuperSkill, appointmentViceCaptain, buyBossTimes, buyTimes, changeGuildName, checkBossResult, checkPropaganda, createGuild, getBulletinBrief, getComments, getFeetInfo, getFriendArenaDefenceTeam, getGuildBossInfo, getGuildByIdOrName, getGuildDetail, getGuildList, getGuildLog, getMembers, getRequestMembers, getRewardInfo, getSatanGift, getState, getTreasureInfo, getTreasurePoint, guildSign, handleRequest, impeachCaptain, kickOut, mergeBossStartBattle, quitGuild, readBulletin, relieveViceCaptain, requestGuild, resetTech, startBattle, startBoss, topAward, transferCaptain, treasureStartBattle, updateBulletin, updateDes, updateGuildIcon, updateRequestCondition, updateTreasureDefenceTeam, upgradeTech
 */

var ResponseHelper = require('../../core/responseHelper');
var logger         = require('../../utils/logger');

// ============================================
// ACTION HANDLERS
// ============================================

var activeSuperSkill = require('./activeSuperSkill');
var appointmentViceCaptain = require('./appointmentViceCaptain');
var buyBossTimes = require('./buyBossTimes');
var buyTimes = require('./buyTimes');
var changeGuildName = require('./changeGuildName');
var checkBossResult = require('./checkBossResult');
var checkPropaganda = require('./checkPropaganda');
var createGuild = require('./createGuild');
var getBulletinBrief = require('./getBulletinBrief');
var getComments = require('./getComments');
var getFeetInfo = require('./getFeetInfo');
var getFriendArenaDefenceTeam = require('./getFriendArenaDefenceTeam');
var getGuildBossInfo = require('./getGuildBossInfo');
var getGuildByIdOrName = require('./getGuildByIdOrName');
var getGuildDetail = require('./getGuildDetail');
var getGuildList = require('./getGuildList');
var getGuildLog = require('./getGuildLog');
var getMembers = require('./getMembers');
var getRequestMembers = require('./getRequestMembers');
var getRewardInfo = require('./getRewardInfo');
var getSatanGift = require('./getSatanGift');
var getState = require('./getState');
var getTreasureInfo = require('./getTreasureInfo');
var getTreasurePoint = require('./getTreasurePoint');
var guildSign = require('./guildSign');
var handleRequest = require('./handleRequest');
var impeachCaptain = require('./impeachCaptain');
var kickOut = require('./kickOut');
var mergeBossStartBattle = require('./mergeBossStartBattle');
var quitGuild = require('./quitGuild');
var readBulletin = require('./readBulletin');
var relieveViceCaptain = require('./relieveViceCaptain');
var requestGuild = require('./requestGuild');
var resetTech = require('./resetTech');
var startBattle = require('./startBattle');
var startBoss = require('./startBoss');
var topAward = require('./topAward');
var transferCaptain = require('./transferCaptain');
var treasureStartBattle = require('./treasureStartBattle');
var updateBulletin = require('./updateBulletin');
var updateDes = require('./updateDes');
var updateGuildIcon = require('./updateGuildIcon');
var updateRequestCondition = require('./updateRequestCondition');
var updateTreasureDefenceTeam = require('./updateTreasureDefenceTeam');
var upgradeTech = require('./upgradeTech');

var actions = {
  activeSuperSkill: activeSuperSkill,
  appointmentViceCaptain: appointmentViceCaptain,
  buyBossTimes: buyBossTimes,
  buyTimes: buyTimes,
  changeGuildName: changeGuildName,
  checkBossResult: checkBossResult,
  checkPropaganda: checkPropaganda,
  createGuild: createGuild,
  getBulletinBrief: getBulletinBrief,
  getComments: getComments,
  getFeetInfo: getFeetInfo,
  getFriendArenaDefenceTeam: getFriendArenaDefenceTeam,
  getGuildBossInfo: getGuildBossInfo,
  getGuildByIdOrName: getGuildByIdOrName,
  getGuildDetail: getGuildDetail,
  getGuildList: getGuildList,
  getGuildLog: getGuildLog,
  getMembers: getMembers,
  getRequestMembers: getRequestMembers,
  getRewardInfo: getRewardInfo,
  getSatanGift: getSatanGift,
  getState: getState,
  getTreasureInfo: getTreasureInfo,
  getTreasurePoint: getTreasurePoint,
  guildSign: guildSign,
  handleRequest: handleRequest,
  impeachCaptain: impeachCaptain,
  kickOut: kickOut,
  mergeBossStartBattle: mergeBossStartBattle,
  quitGuild: quitGuild,
  readBulletin: readBulletin,
  relieveViceCaptain: relieveViceCaptain,
  requestGuild: requestGuild,
  resetTech: resetTech,
  startBattle: startBattle,
  startBoss: startBoss,
  topAward: topAward,
  transferCaptain: transferCaptain,
  treasureStartBattle: treasureStartBattle,
  updateBulletin: updateBulletin,
  updateDes: updateDes,
  updateGuildIcon: updateGuildIcon,
  updateRequestCondition: updateRequestCondition,
  updateTreasureDefenceTeam: updateTreasureDefenceTeam,
  upgradeTech: upgradeTech,
};

// ============================================
// ROUTER
// ============================================

function handle(socket, request, callback) {
  var action = request.action;

  if (!action) {
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.LACK_PARAM), callback);
    return;
  }

  var handler = actions[action];

  if (handler && typeof handler === 'function') {
    handler(socket, request, callback);
  } else {
    logger.warn('Guild', 'Unknown action: ' + action);
    ResponseHelper.sendResponse(socket, 'handler.process',
      ResponseHelper.error(ResponseHelper.ErrorCode.INVALID_COMMAND), callback);
  }
}

module.exports = { handle: handle };
